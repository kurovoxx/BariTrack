from otros.strategy import EstrategiaCalorias

class CaloriasPorPorcion(EstrategiaCalorias):
    def calcular(self, valor):
        return None, int(valor)
