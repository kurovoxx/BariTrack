from otros.strategy import EstrategiaCalorias

class CaloriasPor100Gr(EstrategiaCalorias):
    def calcular(self, valor):
        return int(valor), None
