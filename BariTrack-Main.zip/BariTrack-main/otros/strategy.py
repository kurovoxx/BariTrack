from abc import ABC, abstractmethod

class EstrategiaCalorias(ABC):
    @abstractmethod
    def calcular(self, valor):
        pass
