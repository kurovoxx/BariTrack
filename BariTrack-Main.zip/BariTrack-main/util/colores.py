azul_medio_oscuro = "#28242c"  ##COLOR DE LA BARRA SUPERIOR, DEL MENU LATERAL, COLOR OPCIONAL DE BOTON
gris = "#484c4c" ## COLOR DEL CUERPO PRINCIPAL
azul_mas_clarito = "#2f88c5"  ##COLOR DEL MENU ENCIMA
oscuro = "#101414" ## COLOR LABEL DEL BOTON
celeste_pero_oscuro = "#246474"  ##COLOR DEL DESPLEGABLE DE COMBOBOX

verde_claro = "#34a85a" # Labels generales
verde_oscuro = "#2a8648"  
verde_alegre = "#00ef81" # Barras del gráfico
verde_boton = '#81C784'
gris_label = "#9C9C9C" # Label de alimento registrado y calorias del día
negro_texto = "#1A1A1A" # Se usa para el texto de los label gris y también para el hover de los modulos
primer_label = '#A8D5BA' # label cambiables
segundo_label = '#F5F5DC' # label cambiables
color_entry = '#E6E6FA'

#niveles de riesgo

riesgo_alto = '#cf2323'
riesgo_medio = '#f28c38'
riesgo_bajo = '#4ad138'