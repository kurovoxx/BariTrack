from datetime import datetime
from CTkMessagebox import CTkMessagebox
import sqlite3

class RegistrarPesoCommand:
    def __init__(self, usuario, peso, callback=None):
        self.usuario = usuario
        self.peso = peso
        self.callback = callback

    def execute(self):
        if self.peso == '' or self.peso is None:
            CTkMessagebox(title="Advertencia", message="Ingrese un peso.",
                          icon='warning', option_1="Ok")
            return

        try:
            peso = self.peso.replace(',', '.')
            peso = float(peso)

            conn = sqlite3.connect(f"./users/{self.usuario}/alimentos.db")
            cursor = conn.cursor()

            cursor.execute("SELECT fecha FROM peso ORDER BY num DESC LIMIT 1;")
            resultado = cursor.fetchone()
            ultima_fecha = resultado[0] if resultado else ''

            hoy = datetime.now().strftime('%d-%m-%Y')
            if hoy == ultima_fecha:
                CTkMessagebox(title="Advertencia", message="Solo puedes registrar tu peso una vez al día.",
                              icon='warning', option_1="Ok")
            else:
                query = "INSERT INTO peso (fecha, peso) VALUES (?, ?)"
                cursor.execute(query, (hoy, peso))
                conn.commit()

                CTkMessagebox(title="Éxito", message="Peso actualizado", icon='check', option_1="Ok")

                if self.callback:
                    self.callback()

            conn.close()
        except ValueError:
            CTkMessagebox(title="Advertencia", message="Ingrese un peso válido.",
                          icon='warning', option_1="Ok")
