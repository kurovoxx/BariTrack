import sqlite3
from CTkMessagebox import CTkMessagebox

class EditarRecordatorioCommand:
    def __init__(self, usuario, recordatorio_id, nueva_descripcion):
        self.usuario = usuario
        self.recordatorio_id = recordatorio_id
        self.nueva_descripcion = nueva_descripcion

    def execute(self):
        if not self.nueva_descripcion:
            CTkMessagebox(
                title="Campo vacío",
                message="La descripción no puede estar vacía.",
                icon="warning",
                option_1="Ok"
            )
            return False

        try:
            conn = sqlite3.connect(f"./users/{self.usuario}/alimentos.db")
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE fechas_seleccionadas SET descripcion=? WHERE id=?",
                (self.nueva_descripcion, self.recordatorio_id)
            )
            conn.commit()
            conn.close()

            CTkMessagebox(
                title="Éxito",
                message="Recordatorio actualizado correctamente.",
                icon="info",
                option_1="Ok"
            )
            return True

        except Exception as e:
            print("Error al actualizar el recordatorio:", e)
            CTkMessagebox(
                title="Error",
                message="Error al actualizar el recordatorio.",
                icon="error",
                option_1="Ok"
            )
            return False
