import sqlite3
from datetime import datetime
from CTkMessagebox import CTkMessagebox

class BorrarRecordatorioCommand:
    def __init__(self, usuario, recordatorio_id, calendario_widget=None):
        self.usuario = usuario
        self.recordatorio_id = recordatorio_id
        self.calendario_widget = calendario_widget  # para quitar resaltado

    def execute(self):
        try:
            conn = sqlite3.connect(f"./users/{self.usuario}/alimentos.db")
            cursor = conn.cursor()

            cursor.execute("SELECT fecha FROM fechas_seleccionadas WHERE id=?", (self.recordatorio_id,))
            resultado = cursor.fetchone()

            if not resultado:
                conn.close()
                CTkMessagebox(
                    title="No encontrado",
                    message="No se encontró el recordatorio.",
                    icon="warning",
                    option_1="Ok"
                )
                return False

            fecha_db = resultado[0]

            cursor.execute("DELETE FROM fechas_seleccionadas WHERE id=?", (self.recordatorio_id,))
            conn.commit()
            conn.close()

            if self.calendario_widget:
                try:
                    fecha_dt = datetime.strptime(fecha_db, "%Y-%m-%d").date()
                    for event_id in self.calendario_widget.calevent_get():
                        if self.calendario_widget.calevent_cget(event_id, 'date') == fecha_dt:
                            self.calendario_widget.calevent_remove(event_id)
                            break
                except Exception as e:
                    print("Error al quitar resaltado:", e)

            CTkMessagebox(
                title="Éxito",
                message="Recordatorio borrado correctamente.",
                icon="info",
                option_1="Ok"
            )
            return True

        except Exception as e:
            print("Error al borrar:", e)
            CTkMessagebox(
                title="Error",
                message="Error al borrar el recordatorio.",
                icon="error",
                option_1="Ok"
            )
            return False
