from CTkMessagebox import CTkMessagebox
from datetime import datetime
import sqlite3

class AgregarRecordatorioCommand:
    def __init__(self, usuario, fecha_seleccionada, descripcion, recordatorio_id=None):
        self.usuario = usuario
        self.fecha_seleccionada = fecha_seleccionada
        self.descripcion = descripcion
        self.recordatorio_id = recordatorio_id  # Si viene de edición

    def execute(self):
        if not self.descripcion:
            CTkMessagebox(
                title="Campo vacío",
                message="Por favor ingresa una descripción.",
                icon="warning",
                option_1="Ok"
            )
            return False

        try:
            fecha_db = datetime.strptime(self.fecha_seleccionada, "%d/%m/%Y").strftime("%Y-%m-%d")
            conn = sqlite3.connect(f"./users/{self.usuario}/alimentos.db")
            cursor = conn.cursor()

            if self.recordatorio_id:
                cursor.execute(
                    "UPDATE fechas_seleccionadas SET fecha=?, descripcion=? WHERE id=?",
                    (fecha_db, self.descripcion, self.recordatorio_id)
                )
                mensaje = f"Recordatorio #{self.recordatorio_id} actualizado."
            else:
                cursor.execute(
                    "INSERT INTO fechas_seleccionadas (fecha, descripcion) VALUES (?, ?)",
                    (fecha_db, self.descripcion)
                )
                mensaje = f"Recordatorio agregado para {self.fecha_seleccionada}."

            conn.commit()
            conn.close()

            CTkMessagebox(
                title="Éxito",
                message=mensaje,
                icon="info",
                option_1="Ok"
            )
            return True

        except sqlite3.Error as e:
            print(f"Error al guardar la fecha: {e}")
            CTkMessagebox(
                title="Error",
                message="Hubo un error al guardar la fecha.",
                icon="error",
                option_1="Ok"
            )
            return False
