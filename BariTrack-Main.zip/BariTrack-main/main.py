from Ventanas.Ventana_principal import Main


app = Main()
app.resizable(False, False)
app.mainloop()
